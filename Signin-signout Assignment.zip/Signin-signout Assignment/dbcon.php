<?php
$server = "localhost"; // "localhost" instead of "Local host"
$user = "root"; // "root" instead of "Root"
$password = ""; // Password for your database
$db = "kiep"; // Database name

$con = mysqli_connect($server,$user,$password,$db);
if (!$con) 
{
    echo "Connection to the server failed";
}
?>