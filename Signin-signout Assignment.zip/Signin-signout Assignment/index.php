<?php
 Session_start();


 if($_SESSION['name']==""){
 header('Location:login.html');
 }
 
 ?>
 <!DOCTYPE html>
 <html lang= "en">
    <head>  
        <meta charset= "UFT-8">
        <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
        <title>KIEP_SKIES</title>
        <link rel="stylesheet" href="styles.css">
</head>
<body>

<p>Welcome <?php  echo  $_SESSION ["name"];?>  for KIEP_SKIES Program at Mama Ngina University College</p>
<br>

<a href="logout.php">Logout</a>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>




<footer>
<p>&copy; 2024| KIEP_SKIES| All rights reserved.</p>
</footer>
</body>
</html>